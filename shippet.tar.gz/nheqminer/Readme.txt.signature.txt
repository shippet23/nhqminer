{
  "hash": "9cdd08f2f584def4494eaf3236741f48c606f3fdf632bcdd44b3e3dd874de4de",
  "signature": "AWcbEAABQR+pIVksKmAXTuKABU7GwqLXCpaAVtkYtNiiLMdS6WtHcBH9MqPqkihyTB1KryMb4CCbxIXIuuCsYjajReerzEW/",
  "signer": "Verus Coin Foundation Releases@"
}
